/*
 * main.h
 *
 *  Created on: Dec 30, 2019
 *      Author: A310
 */

#ifndef MAIN_H_
#define MAIN_H_

typedef struct 

{ 
    int16_t x; 
    int16_t y; 
    int16_t z; 
    int8_t id; 
}MMA845X; 
typedef enum 
{ 
  IDLE,  
  TRANSMIT, 
  RECEIVE 
}MMA845_STATE; 

#endif /* MAIN_H_ */
