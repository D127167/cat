/* ###################################################################
**     Filename    : main.c
**     Project     : d10619127_final
**     Processor   : MKL25Z128VLK4
**     Version     : Driver 01.01
**     Compiler    : GNU C Compiler
**     Date/Time   : 2019-12-30, 10:49, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.01
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "TSS1.h"
#include "CI2C1.h"
#include "TU1.h"
#include "TU2.h"
#include "TU3.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
#include "main.h" 
//#include "stdio.h" 

/* User includes (#include below this line is not maintained by Processor Expert) */
volatile bool DataReceivedFlg = FALSE; 
volatile bool DataTransmittedFlg = FALSE; 

uint8_t OutData[2] = {0x2A, 0x01};  
uint8_t InData[6]; 
LDD_TError Error; 
LDD_TDeviceData *MyTimerPtr; 
LDD_TDeviceData *MyI2CPtr; 
MMA845X mma845x; 
int16_t mma845_tmp;
volatile bool OnOff=TRUE;
int xValue,yValue;
static MMA845_STATE measuring = IDLE; 
static MMA845_STATE measuring_last = RECEIVE; 
void Timer_Interrupt_CB(void) 
{ 
   if(measuring == IDLE) 

   {   if(measuring_last == TRANSMIT)  measuring = RECEIVE;  
       else if(measuring_last == RECEIVE)  measuring = TRANSMIT; 
   } 
}

void MMA845X_Init(void) 
{   
Error = CI2C1_MasterSendBlock(MyI2CPtr, &OutData, 2, LDD_I2C_NO_SEND_STOP); 
  while (!DataTransmittedFlg);  
  DataTransmittedFlg = FALSE; 
  OutData[0] = 13;  

Error = CI2C1_MasterSendBlock(MyI2CPtr, &OutData, 1, LDD_I2C_NO_SEND_STOP); 
  while (!DataTransmittedFlg);   
  DataTransmittedFlg = FALSE; 

Error = CI2C1_MasterReceiveBlock(MyI2CPtr, &mma845x.id, 1, LDD_I2C_SEND_STOP); 
  while (!DataReceivedFlg); 
  DataReceivedFlg = FALSE; 

} 

void MMA845X_Poll(void) 
{    

    if(measuring == TRANSMIT) 
    { 
      measuring = IDLE; 
      measuring_last = TRANSMIT; 
      OutData[0] = 1; 

Error = CI2C1_MasterSendBlock(MyI2CPtr, &OutData, 1, LDD_I2C_NO_SEND_STOP); 
      while (!DataTransmittedFlg);  
      DataTransmittedFlg = FALSE;    
    }
    else if(measuring == RECEIVE) 
    { 

      measuring = IDLE; 
      measuring_last = RECEIVE;
      Error = CI2C1_MasterReceiveBlock(MyI2CPtr, &InData, 6, LDD_I2C_SEND_STOP); 
      while (!DataReceivedFlg); 
      DataReceivedFlg = FALSE;   
      mma845_tmp = InData[1] | (InData[0] << 8); 
      mma845x.x = (mma845_tmp / 4); 
      mma845_tmp = InData[3] | (InData[2] << 8); 
      mma845x.y = (mma845_tmp / 4); 
      mma845_tmp = InData[5] | (InData[4] << 8);      
      mma845x.z = (mma845_tmp / 4);    
      xValue=mma845x.x;
      if(xValue>2000)xValue=2000;
      if(xValue<-2000)xValue=2000;
      TU2_SetOffsetTicks(TU2_DeviceData,0,xValue*6+12000);
      if(yValue>2000)yValue=2000;
      if(yValue<-2000)yValue=-2000;
      TU3_SetOffsetTicks(TU3_DeviceData,0,yValue*6+12000);
           
    } 
} 

/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
  /* Write your local variable definition here */


  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  /* For example:  */
  Configure(); 
	MyI2CPtr = CI2C1_Init(NULL); 
	  MyTimerPtr = TU1_Init(NULL)
			  ; 
	  MMA845X_Init(); 
	  for(;;) {
		  if(OnOff){
			  TU2_SetOffsetTicks(TU2_DeviceData,0,0);
			  TU3_SetOffsetTicks(TU3_DeviceData,0,0);
		  }
		  else{
			  MMA845X_Poll();
		  }
		  TSS_Task();
	  }
  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.3 [05.09]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
